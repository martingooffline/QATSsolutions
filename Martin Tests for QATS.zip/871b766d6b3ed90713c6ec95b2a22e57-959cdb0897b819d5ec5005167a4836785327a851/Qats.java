import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.IOException;

public class Qats {
    private WebDriver driver;
    private final String BASE_URL = "http://localhost/QATS_technical_task1_FE_automation-1.pdf";



    @Before
    public void setUp(){
        System.setProperty("webdriver.chrome.driver","src/test/resources/drivers/chromedriver.exe");
        driver = new ChromeDriver();

    }

    @Test
    public void TestCase1() {
        driver.manage().window().maximize();
        driver.get(BASE_URL);
        driver.findElement(By.id("email")).sendKeys("tech_task@qats.sk");
        driver.findElement(By.id("password")).sendKeys("124lkjAF89as");
        driver.findElement(By.id("button-signin")).click();

        driver.findElement(By.id("newpost")).click();
        driver.findElement(By.id("articletitle")).sendKeys("MARTIN ARTICLE");
        driver.findElement(By.id("articleabout")).sendKeys("ABOUT ARTICLE");
        driver.findElement(By.id("writearticle")).sendKeys("MY ARTICLE");
        driver.findElement(By.id("entertags")).sendKeys("enter tags");
        driver.findElement(By.id("publisharticle")).click();

        driver.findElement(By.id("settings")).click();
        driver.findElement(By.id("logout")).click();
    }

    @Test
    public void TestCase2() {
        driver.manage().window().maximize();
        driver.get(BASE_URL);
        Assert.assertTrue(driver.findElement(By.id("martin-article")).isDisplayed());
        driver.findElement(By.id("martin-article")).click();
        driver.findElement(By.id("delete")).click();
        driver.findElement(By.id("settings")).click();
        driver.findElement(By.id("logout")).click();
    }

    @After
    public void tearDown() throws IOException {
        driver.close();
        driver.quit();

    }
}
